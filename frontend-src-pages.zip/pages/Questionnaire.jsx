// src/pages/Questionnaire.jsx

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ref, set } from "firebase/database";
import { db } from "../firebase";
import { useAuth } from "../context/AuthContext";

export default function Questionnaire() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [answers, setAnswers] = useState({
    ageGroup: "",
    income: "",
    expenses: "",
    risk: "",
    goals: "",
    investAmount: "",
    horizon: "",
    loans: "",
  });

  const handleChange = (e) => {
    setAnswers({ ...answers, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!currentUser) {
      alert("Please login to continue.");
      return;
    }

    const formData = {
      age: answers.ageGroup,
      income: Number(answers.income),
      expenses: Number(answers.expenses),
      riskTolerance: answers.risk,
      investmentHorizon: Number(answers.horizon),
      goals: answers.goals,
      investAmount: Number(answers.investAmount),
      loans: answers.loans
    };

    try {
      await set(ref(db, `users/${currentUser.uid}/formData`), formData);
      console.log("✅ Form data saved successfully!", formData);
      navigate("/planner");
    } catch (error) {
      console.error("❌ Error saving form data:", error);
      alert("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-100 flex items-center justify-center p-4">
      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-2xl space-y-6"
      >
        <h2 className="text-3xl font-bold text-center text-green-600">
          Let's build your financial profile 🌟
        </h2>

        {/* Age Group */}
        <div>
          <label className="block mb-1 font-medium">Your age group:</label>
          <select name="ageGroup" value={answers.ageGroup} onChange={handleChange} required className="w-full border rounded px-3 py-2">
            <option value="">Select</option>
            <option value="18-25">18–25</option>
            <option value="26-35">26–35</option>
            <option value="36-50">36–50</option>
            <option value="51+">51+</option>
          </select>
        </div>

        {/* Monthly Income */}
        <div>
          <label className="block mb-1 font-medium">Monthly income (₹):</label>
          <input type="number" name="income" value={answers.income} onChange={handleChange} required className="w-full border rounded px-3 py-2" />
        </div>

        {/* Monthly Expenses */}
        <div>
          <label className="block mb-1 font-medium">Monthly expenses (₹):</label>
          <input type="number" name="expenses" value={answers.expenses} onChange={handleChange} required className="w-full border rounded px-3 py-2" />
        </div>

        {/* Risk Appetite */}
        <div>
          <label className="block mb-1 font-medium">Risk appetite:</label>
          <select name="risk" value={answers.risk} onChange={handleChange} required className="w-full border rounded px-3 py-2">
            <option value="">Select</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>

        {/* Investment Horizon */}
        <div>
          <label className="block mb-1 font-medium">Investment horizon (in years):</label>
          <input type="number" name="horizon" value={answers.horizon} onChange={handleChange} required className="w-full border rounded px-3 py-2" />
        </div>

        {/* Goals */}
        <div>
          <label className="block mb-1 font-medium">Financial goals:</label>
          <input type="text" name="goals" value={answers.goals} onChange={handleChange} placeholder="Eg: Buy a house, retirement" required className="w-full border rounded px-3 py-2" />
        </div>

        {/* Monthly Investment */}
        <div>
          <label className="block mb-1 font-medium">How much can you invest per month (₹)?</label>
          <input type="number" name="investAmount" value={answers.investAmount} onChange={handleChange} required className="w-full border rounded px-3 py-2" />
        </div>

        {/* Ongoing Loans */}
        <div>
          <label className="block mb-1 font-medium">Any ongoing loans or EMIs?</label>
          <input type="text" name="loans" value={answers.loans} onChange={handleChange} placeholder="Eg: Home loan, car EMI, none" required className="w-full border rounded px-3 py-2" />
        </div>

        <motion.button type="submit" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
          className="w-full bg-gradient-to-r from-green-400 to-blue-500 text-white py-3 rounded-lg font-semibold shadow-md">
          Submit & Generate Plan 🚀
        </motion.button>
      </motion.form>
    </div>
  );
}
