import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { generatePlan } from '../utils/generatePlan';
import getExplanation from "../utils/getExplanation";
import axios from "axios";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { signOut } from "firebase/auth";
import { auth, db } from "../firebase";
import { ref, get } from "firebase/database";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function Planner() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [formData, setFormData] = useState(null);
  const [missingFields, setMissingFields] = useState([]);
  const [loadingForm, setLoadingForm] = useState(true);
  const [generatedPlan, setGeneratedPlan] = useState(null);
  const [chatQuestion, setChatQuestion] = useState("");
  const [chatAnswer, setChatAnswer] = useState("");
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentUser) {
      const dataRef = ref(db, `users/${currentUser.uid}/formData`);
      get(dataRef)
        .then((snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.val();
            const requiredFields = [
              "age", "income", "expenses", "riskTolerance", "investmentHorizon", "goals"
            ];
            const isValid = requiredFields.every((field) =>
              data.hasOwnProperty(field) && data[field] !== null && data[field] !== undefined && data[field] !== ""
            );

            if (!isValid) {
              const missing = requiredFields.filter(field =>
                !data.hasOwnProperty(field) || data[field] === null || data[field] === undefined || data[field] === ""
              );
              setMissingFields(missing);
              setFormData(null);
            } else {
              setFormData(data);
            }
          } else {
            setFormData(null);
          }
          setLoadingForm(false);
        })
        .catch((error) => {
          console.error("Error fetching user data:", error);
          setLoadingForm(false);
        });
    }
  }, [currentUser]);

  // ✅ Fetch Plan After formData is Set
  useEffect(() => {
    if (formData && currentUser?.uid) {
      const fetchPlan = async () => {
        try {
          const plan = await generatePlan(currentUser.uid, formData);
          setGeneratedPlan(plan);
        } catch (err) {
          console.error("❌ Failed to generate plan:", err);
        }
      };
      fetchPlan();
    }
  }, [formData, currentUser]);

  const handleLogout = () => {
    signOut(auth);
    window.location.href = "/login";
  };

  if (!currentUser) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-100"><p className="text-lg text-red-600 font-semibold">Please login to view your plan.</p></div>;
  }

  if (loadingForm) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-100"><p className="text-lg text-gray-600">Loading your data...</p></div>;
  }

  if (!formData) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 px-4 text-center">
        <p className="text-lg text-red-600 font-semibold mb-4">No data found or data is incomplete. Please complete the questionnaire first.</p>
        {missingFields.length > 0 && (
          <div className="bg-white p-4 rounded shadow text-left">
            <p className="text-gray-700 font-semibold mb-2">Missing Fields:</p>
            <ul className="list-disc pl-5 text-red-500">
              {missingFields.map((field) => <li key={field}>{field}</li>)}
            </ul>
          </div>
        )}
      </div>
    );
  }

  if (!generatedPlan) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-100"><p className="text-lg text-blue-600 font-semibold">Generating your personalized plan...</p></div>;
  }

  const {
    portfolio = [],
    projectedReturn = 0,
    riskScore = "N/A",
    diversificationScore = "N/A"
  } = generatedPlan;

  const monthlyEMI = 5000;
  const yearlyInvestment = monthlyEMI * 12;
  const inflationRate = 0.06;
  const adjustedReturnRate = (1 + projectedReturn / 100) / (1 + inflationRate) - 1;
  const adjustedReturnPercent = (adjustedReturnRate * 100).toFixed(2);
  const cumulativeReturns = (
    yearlyInvestment *
    ((Math.pow(1 + adjustedReturnRate, formData.investmentHorizon) - 1) / adjustedReturnRate)
  ).toFixed(2);

  const explanation = getExplanation(
    formData,
    projectedReturn,
    riskScore,
    diversificationScore,
    monthlyEMI
  );

  const statCards = [
    { title: "Projected Annual Return", value: `${projectedReturn}%` },
    { title: "Inflation-Adjusted Return", value: `${adjustedReturnPercent}%` },
    { title: "Cumulative Return (₹)", value: `₹${cumulativeReturns}` },
    { title: "Risk Score", value: riskScore },
    { title: "Diversification Score", value: diversificationScore },
  ];

  const chartData = {
    labels: portfolio.map((item) => item.name),
    datasets: [
      {
        data: portfolio.map((item) => item.percent),
        backgroundColor: ["#34D399", "#60A5FA", "#FBBF24", "#F472B6", "#FACC15", "#A78BFA"],
        borderWidth: 2,
      },
    ],
  };

  const downloadPDF = async () => {
    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/generate-pdf",
        { formData, explanation },
        { responseType: "blob" }
      );
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "Financial_Plan_Summary.pdf");
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error("Error downloading PDF:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-100 p-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl p-8"
      >
        <div className="text-sm text-right text-gray-600 mb-4">
          Logged in as <strong>{currentUser.displayName || currentUser.email}</strong>
        </div>

        <h1 className="text-3xl font-bold mb-4 text-green-600">
          Your Personalized Financial Plan 🌟
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {statCards.map((card, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-xl p-4 shadow-lg text-center"
            >
              <h3 className="text-lg font-semibold">{card.title}</h3>
              <p className="text-2xl font-bold mt-2">{card.value}</p>
            </div>
          ))}
        </div>

        <p className="mb-6 text-gray-700">
          Based on your answers, here’s a suggested diversified portfolio to help you grow and secure your future:
        </p>

        <ul className="space-y-3 mb-6">
          {portfolio.map((item, idx) => (
            <li key={idx} className="flex justify-between bg-gray-50 rounded p-3 shadow-sm">
              <span>{item.name}</span>
              <span className="font-semibold">{item.percent}%</span>
            </li>
          ))}
        </ul>

        <div className="mb-10">
          <h2 className="text-xl font-bold text-green-600 mb-4">Portfolio Allocation</h2>
          <Doughnut data={chartData} />
        </div>

        <div className="bg-gray-50 rounded p-4 mt-6 shadow">
          <h3 className="text-xl font-semibold mb-2 text-green-600">Why this plan?</h3>
          <p className="text-gray-700 whitespace-pre-line">{explanation}</p>
        </div>

        <button
          onClick={() => navigate("/")}
          className="mt-8 bg-green-500 text-white px-6 py-3 rounded-full shadow hover:bg-green-600 transition"
        >
          Back to Home
        </button>

        <button
          onClick={handleLogout}
          className="mt-4 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        >
          Logout
        </button>

        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-4 text-green-600">Ask Your AI Finance Advisor 🤖💬</h2>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setLoading(true);
              setChatAnswer("");

              try {
                const res = await axios.get("http://127.0.0.1:8000/ask", {
                  params: { question: chatQuestion },
                });
                setChatAnswer(res.data.answer);
                setSources(res.data.sources || []);
              } catch (err) {
                console.error(err);
                setChatAnswer("Error fetching answer. Please try again.");
              } finally {
                setLoading(false);
              }
            }}
            className="flex flex-col gap-4"
          >
            <input
              type="text"
              value={chatQuestion}
              onChange={(e) => setChatQuestion(e.target.value)}
              placeholder="Type your finance question..."
              className="border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button
              type="submit"
              className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
            >
              Ask
            </button>
            <button
              onClick={downloadPDF}
              className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-full shadow hover:bg-blue-700 transition"
            >
              Download PDF Summary 📄
            </button>
          </form>

          {loading && <p className="mt-4 text-gray-500">Loading...</p>}

          {chatAnswer && (
            <div className="mt-4 bg-gray-50 border border-gray-200 rounded p-4">
              <h3 className="font-semibold mb-2">AI Answer:</h3>
              <p>{chatAnswer}</p>
            </div>
          )}

          {sources.length > 0 && (
            <>
              <h4 className="mt-4 font-semibold">Sources:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {sources.map((src, idx) => (
                  <li key={idx}>
                    <strong>{src.metadata?.source}</strong>:{" "}
                    {src.content?.substring(0, 80)}...
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
