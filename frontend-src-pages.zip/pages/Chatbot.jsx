import { motion } from "framer-motion";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 flex flex-col items-center justify-center text-gray-800 relative overflow-hidden">
      {/* Decorative blurred circles */}
      <div className="absolute top-0 -left-20 w-72 h-72 bg-green-200 rounded-full filter blur-3xl opacity-50"></div>
      <div className="absolute bottom-0 -right-20 w-72 h-72 bg-blue-200 rounded-full filter blur-3xl opacity-50"></div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="max-w-3xl text-center px-6"
      >
        <h1 className="text-5xl md:text-6xl font-extrabold mb-6 leading-tight bg-gradient-to-r from-green-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
          Your Personal AI Finance Planner
        </h1>
        <p className="text-lg md:text-xl mb-10">
          Plan. Diversify. Grow. — AI-powered financial guidance personalized just for you.
        </p>

        <Link to="/questionnaire">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            className="bg-gradient-to-r from-green-400 to-blue-500 text-white px-8 py-4 rounded-full shadow-lg font-semibold transition-all duration-300"
          >
            Get Started
          </motion.button>
        </Link>
      </motion.div>

      {/* Floating illustration (optional) */}
      <motion.img
        src="/assets/finance-illustration.svg" // You can replace with your illustration
        alt="Finance Illustration"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, delay: 0.5 }}
        className="mt-12 w-80"
      />
    </div>
  );
}
