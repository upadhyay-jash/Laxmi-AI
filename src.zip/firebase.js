// src/firebase.js

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

// ✅ Firebase config with CORRECT regional database URL
const firebaseConfig = {
  apiKey: "AIzaSyATdQi54p0Kol5E6CroJPswSZzzKAZmNq0",
  authDomain: "financeragbot.firebaseapp.com",
  projectId: "financeragbot",
  storageBucket: "financeragbot.appspot.com",
  messagingSenderId: "828842673300",
  appId: "1:828842673300:web:b60ec101f5e5716262e081",

  // ✅ Corrected regional URL as per warning
  databaseURL: "https://financeragbot-default-rtdb.asia-southeast1.firebasedatabase.app",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

export { auth, db };
