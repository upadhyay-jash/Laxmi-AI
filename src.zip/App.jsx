import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Signup from "./pages/Signup";
import Questionnaire from "./pages/Questionnaire";
import ForgotPassword from "./pages/ForgotPassword";
import Planner from "./pages/Planner";
import PrivateRoute from "./components/PrivateRoute";
import Login from "./pages/Login.js"

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/questionnaire" element={<Questionnaire />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route
          path="/planner"
          element={
            <PrivateRoute>
              <Planner />
            </PrivateRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
