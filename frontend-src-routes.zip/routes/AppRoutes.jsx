import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "../pages/Home";
import Questionnaire from "../pages/Questionnaire";
import Dashboard from "../pages/Dashboard";
import Chatbot from "../pages/Chatbot";
import NotFound from "../pages/NotFound";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/questionnaire" element={<Questionnaire />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/chatbot" element={<Chatbot />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;
