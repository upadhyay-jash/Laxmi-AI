from fastapi import APIRouter, HTTPException
from firebase_admin import db
from app.utils.llm_ops import call_llm_for_plan

router = APIRouter()

@router.post("/generate-plan")
def generate_plan(uid: str):
    try:
        # Step 1: Fetch form data from Firebase Realtime DB
        ref = db.reference(f"/users/{uid}/formData")
        form_data = ref.get()

        if not form_data:
            raise HTTPException(status_code=404, detail="Form data not found.")

        # Step 2: Clean and parse inputs safely
        try:
            age = form_data.get("age", "Not specified")
            income = int(form_data.get("income", 0))
            expenses = int(form_data.get("expenses", 0))
            invest_amount = int(form_data.get("investAmount", 0))
            investment_horizon = int(form_data.get("investmentHorizon", 30))
            risk_tolerance = form_data.get("riskTolerance", "Moderate")
            goals = form_data.get("goals", "No goals provided")
            loans = form_data.get("loans", "0")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid input: {e}")

        # Step 3: Basic EMI and surplus calculation
        surplus = income - expenses
        emi = min(invest_amount, surplus)

        # Step 4: Call Azure OpenAI LLM
        llm_response = call_llm_for_plan(
            age=age,
            income=income,
            expenses=expenses,
            investment_amount=invest_amount,
            investment_horizon=investment_horizon,
            risk_tolerance=risk_tolerance,
            goals=goals,
            loans=loans,
            emi=emi,
            surplus=surplus
        )

        return llm_response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
