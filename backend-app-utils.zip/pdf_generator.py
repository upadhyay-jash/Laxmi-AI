# app/utils/pdf_generator.py

def generate_pdf(content):
    # Placeholder PDF generator function
    return b"%PDF-1.4\n% Mock PDF binary data"
