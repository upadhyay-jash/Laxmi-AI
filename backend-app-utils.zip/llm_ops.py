import os
import json
from dotenv import load_dotenv
from langchain.chains import RetrievalQA
from langchain_openai import AzureChatOpenAI
from app.utils.pinecone_ops import get_pinecone_vectorstore
from langchain.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from app.utils.logger import logger
from openai import AzureOpenAI

load_dotenv()

# 🔐 Load environment variables
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_DEPLOYMENT_NAME = os.getenv("AZURE_DEPLOYMENT_NAME")
AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2023-12-01-preview")

# 🌐 Azure client setup
client = AzureOpenAI(
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_API_VERSION,
    azure_endpoint=AZURE_ENDPOINT,
)

# 🔁 Get LangChain-compatible LLM for RAG
def get_llm():
    llm = AzureChatOpenAI(
        azure_endpoint=AZURE_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_API_VERSION,
        azure_deployment=AZURE_DEPLOYMENT_NAME,
        model_name="gpt-35-turbo"
    )

    prompt = ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(
            "You are an expert personal finance assistant. Respond in simple terms with bullet-pointed sources."
        ),
        HumanMessagePromptTemplate.from_template("{question}")
    ])

    return llm, prompt


# 🧠 LLM Plan Generation
def call_llm_for_plan(user_prompt: str):
    try:
        logger.info("📡 Calling LLM for plan generation...")

        response = client.chat.completions.create(
            model=AZURE_DEPLOYMENT_NAME,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a financial planning AI. Always return output in this JSON structure:\n\n"
                        "{\n"
                        "  \"summary\": string,\n"
                        "  \"projectedReturn\": string (in %),\n"
                        "  \"expectedCorpus\": string (in ₹),\n"
                        "  \"monthlyInvestment\": string (in ₹),\n"
                        "  \"emi\": string (in ₹),\n"
                        "  \"riskScore\": string,\n"
                        "  \"diversificationScore\": string,\n"
                        "  \"inflationAdjustedReturn\": string (in ₹),\n"
                        "  \"cumulativeReturn\": string (in ₹),\n"
                        "  \"portfolio\": [ {\"name\": string, \"percent\": number} ],\n"
                        "  \"tips\": [string, string, ...]\n"
                        "}\n\n"
                        "Respond only in JSON. Do not include any explanation outside JSON."
                    )
                },
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=1200
        )

        content = response.choices[0].message.content.strip()

        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            logger.warning("⚠️ Could not parse JSON. Returning raw.")
            return {
                "error": "Invalid JSON",
                "raw_response": content,
                "portfolio": [],
                "summary": "Could not generate a financial plan.",
                "projectedReturn": "N/A",
                "expectedCorpus": "N/A",
                "monthlyInvestment": "N/A",
                "riskScore": "N/A",
                "diversificationScore": "N/A",
                "tips": []
            }

        # ✅ Fill in missing keys safely
        defaults = {
            "summary": "This plan balances growth and stability tailored to your risk profile.",
            "projectedReturn": "10%",
            "expectedCorpus": "1500000",
            "monthlyInvestment": "5000",
            "emi": "0",
            "riskScore": "Moderate",
            "diversificationScore": "Balanced",
            "inflationAdjustedReturn": "1200000",
            "cumulativeReturn": "1800000",
            "tips": ["Diversify across asset classes", "Review your plan annually"]
        }

        for key, default_value in defaults.items():
            if key not in parsed or not parsed[key] or parsed[key] in ["NaN", "N/A", "None", None]:
                parsed[key] = default_value

        if "portfolio" not in parsed or not isinstance(parsed["portfolio"], list) or len(parsed["portfolio"]) == 0:
            parsed["portfolio"] = [
                {"name": "Equity Mutual Funds", "percent": 50},
                {"name": "Fixed Income", "percent": 25},
                {"name": "Gold", "percent": 15},
                {"name": "Cash/FDs", "percent": 10}
            ]

        return parsed

    except Exception as e:
        logger.error(f"❌ Error in call_llm_for_plan: {e}", exc_info=True)
        return {
            "error": str(e),
            "portfolio": [],
            "summary": "N/A",
            "projectedReturn": "N/A",
            "expectedCorpus": "N/A",
            "monthlyInvestment": "N/A",
            "riskScore": "N/A",
            "diversificationScore": "N/A",
            "tips": []
        }


# 📚 RAG Question Answering
def ask_question(query, filters=None):
    try:
        logger.info(f"Query received: {query}")
        if filters:
            logger.info(f"Using filters: {filters}")

        vectorstore = get_pinecone_vectorstore()
        retriever = vectorstore.as_retriever(search_kwargs={"filter": filters, "k": 8})
        docs_and_scores = vectorstore.similarity_search_with_score(query, k=8, filter=filters)

        docs_and_scores_sorted = sorted(docs_and_scores, key=lambda x: x[1], reverse=True)[:3]
        top_docs = [doc for doc, _ in docs_and_scores_sorted]

        llm, prompt = get_llm()
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="map_reduce",
            retriever=retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": prompt}
        )

        result = qa_chain.invoke({"query": query, "input_documents": top_docs})
        answer = result["result"]
        sources = result["source_documents"]

        seen = set()
        unique_sources = [doc for doc in sources if not (doc.page_content in seen or seen.add(doc.page_content))]

        return answer, unique_sources

    except Exception as e:
        logger.error(f"❌ Error in ask_question: {e}", exc_info=True)
        return "An error occurred during question answering.", []
