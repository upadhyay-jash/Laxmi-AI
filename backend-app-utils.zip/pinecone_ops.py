import os
import time
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec
from langchain.vectorstores import Pinecone as PineconeVectorStore
from langchain.embeddings import HuggingFaceEmbeddings

load_dotenv()

pinecone_api_key = os.getenv("PINECONE_API_KEY")
index_name = "finance-bot-index"

embeddings = HuggingFaceEmbeddings()

def get_pinecone_vectorstore():
    pc = Pinecone(api_key=pinecone_api_key)

    if index_name not in pc.list_indexes().names():
        print(f"Creating new index: {index_name}")
        pc.create_index(
            name=index_name,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
        time.sleep(2)
    else:
        print(f"Connecting to existing index: {index_name}")

    index = pc.Index(name=index_name)
    return PineconeVectorStore(index=index, embedding=embeddings, text_key="text")

def upsert_documents(texts, metadatas=None):
    vectorstore = get_pinecone_vectorstore()
    ids = vectorstore.add_texts(texts, metadatas=metadatas)
    print("🧠 Documents upserted with vector IDs:", ids)
    return "✅ Upsert successful"
