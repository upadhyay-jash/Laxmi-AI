"""from app.utils.llm_ops import ask_question

# Example usage
question = "Explain what is a robo-advisor in simple terms."
response = ask_question(question)
print("Response from LLM:")
print(response)

print("\n--- Source Documents ---")
for doc in sources:
    print(doc.page_content)
    print(f"Metadata: {doc.metadata}")
    print("---")"""

from app.utils.llm_ops import ask_question

question = "What is a robo-advisor?"
answer, sources = ask_question(question)

print("\nAnswer:")
print(answer)

print("\nSources:")
for doc in sources:
    print(f"- {doc.page_content[:120]}...")
    print(f"  Metadata: {doc.metadata}")
