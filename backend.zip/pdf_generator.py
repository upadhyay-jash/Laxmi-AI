from fpdf import FPDF
from datetime import datetime

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 16)
        self.cell(0, 10, 'Your Personalized Financial Plan Summary', ln=True, align='C')
        self.ln(10)

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 14)
        self.set_text_color(0, 102, 204)
        self.cell(0, 10, title, ln=True)
        self.set_text_color(0, 0, 0)

    def chapter_body(self, body):
        self.set_font('Arial', '', 12)
        self.multi_cell(0, 10, body)
        self.ln()

def generate_pdf(form_data, explanation):
    pdf = PDF()
    pdf.add_page()

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    pdf.chapter_title("User Profile")
    profile = f"""
    Name: {form_data.get('name', 'User')}
    Age: {form_data['age']}
    Income: ₹{form_data['income']}
    Expenses: ₹{form_data['expenses']}
    Risk Tolerance: {form_data['riskTolerance']}
    Investment Horizon: {form_data['investmentHorizon']} years
    Goals: {form_data['goals']}
    Date: {now}
    """
    pdf.chapter_body(profile)

    pdf.chapter_title("Financial Plan Summary")
    pdf.chapter_body(explanation)

    filepath = f"plan_summary_{form_data['age']}_{now.replace(':', '_').replace(' ', '_')}.pdf"
    pdf.output(filepath)

    return filepath
