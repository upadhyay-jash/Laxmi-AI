from app.utils.pinecone_ops import get_pinecone_vectorstore, upsert_documents

# Example docs
docs = [
    "Automated trading systems help traders execute orders automatically based on predefined criteria.",
    "Financial analysis includes ratio analysis, trend analysis, and vertical analysis to assess company performance.",
    "Robo-advisors are AI-driven platforms providing automated, algorithm-based financial planning services."
]

metadatas = [
    {"source": "Investopedia", "category": "Trading"},
    {"source": "Corporate Finance Institute", "category": "Analysis"},
    {"source": "NerdWallet", "category": "Advisory"}
]

# Upsert documents
print(upsert_documents(docs, metadatas))

# Get vectorstore
vectorstore = get_pinecone_vectorstore()

query = "What is a robo-advisor?"

# Query with metadata filter
results = vectorstore.similarity_search(
    query,
    k=3,
    filter={"category": "Advisory"}
)

print("\n--- Query Results (Filtered: Advisory) ---")
for doc in results:
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")
    print("---")
