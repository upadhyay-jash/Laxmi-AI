from fastapi import FastAPI, Query, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
import os
from dotenv import load_dotenv
from functools import lru_cache

# 🔐 Optional: Rate Limiting - comment out if not using slowapi
try:
    from slowapi import Limiter
    from slowapi.util import get_remote_address
    from slowapi.middleware import SlowAPIMiddleware
    from slowapi.errors import RateLimitExceeded
    rate_limit_enabled = True
except ImportError:
    print("⚠️ 'slowapi' not found, rate limiting disabled.")
    rate_limit_enabled = False

from app.utils.llm_ops import ask_question, call_llm_for_plan  # Your custom LLM functions
from app.utils.pdf_generator import generate_pdf  # Adjusted import path

# Load .env
load_dotenv()

app = FastAPI(title="💰 Laxmi AI – Personal Finance RAG Bot")

# 🔒 Rate limiting setup (if available)
if rate_limit_enabled:
    limiter = Limiter(key_func=get_remote_address)
    app.state.limiter = limiter
    app.add_middleware(SlowAPIMiddleware)

# 🌐 CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Use specific origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 📛 Rate Limit Error Handler
if rate_limit_enabled:
    @app.exception_handler(RateLimitExceeded)
    async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded. Please slow down!"}
        )

# ✅ Root check
@app.get("/")
async def root():
    return {"message": "Backend running successfully 🚀"}

# 🧠 Caching for frequently asked questions
@lru_cache(maxsize=100)
def cached_answer(question: str):
    return ask_question(question, None)

# 📩 Ask endpoint (RAG)
@app.get("/ask")
# Apply limiter only if slowapi is available
async def ask_endpoint(
    question: str = Query(...),
    category: str = Query(None)
):
    try:
        filters = {"category": {"$eq": category}} if category else None
        answer, sources = ask_question(question, filters) if filters else cached_answer(question)

        source_data = []
        seen_contents = set()
        for doc in sources:
            if doc.page_content not in seen_contents:
                seen_contents.add(doc.page_content)
                source_data.append({
                    "content": doc.page_content,
                    "metadata": doc.metadata
                })

        return {
            "answer": answer,
            "sources": source_data
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process question: {str(e)}")

# ✅ Feedback route
class Feedback(BaseModel):
    question: str
    answer: str
    helpful: bool

@app.post("/feedback")
async def submit_feedback(feedback: Feedback):
    try:
        print(f"📥 Feedback received: {feedback.dict()}")
        return {"message": "✅ Feedback received. Thank you!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save feedback: {str(e)}")

# ✅ PDF Generator route
@app.post("/generate-pdf")
async def generate_pdf_summary(request: Request):
    data = await request.json()
    form_data = data.get("formData")
    explanation = data.get("explanation")

    filepath = generate_pdf(form_data, explanation)
    return FileResponse(filepath, filename="Financial_Plan_Summary.pdf", media_type='application/pdf')

# ✅ Plan generation route (calls LLM)
class PlanInput(BaseModel):
    age: str
    income: int
    expenses: int
    investAmount: int
    investmentHorizon: int
    goals: str
    loans: str
    riskTolerance: str

@app.post("/generate-plan")
async def generate_plan(input: PlanInput):
    try:
        user_prompt = f"""
        The user is planning finances. Based on the following inputs, generate a detailed plan in JSON:

        - Age: {input.age}
        - Income: ₹{input.income}
        - Expenses: ₹{input.expenses}
        - Investment Amount: ₹{input.investAmount}
        - Investment Horizon: {input.investmentHorizon} years
        - Financial Goals: ₹{input.goals}
        - Risk Tolerance: {input.riskTolerance}
        - Loans: ₹{input.loans}

        Your JSON output must include:
        {{
          "summary": "...",
          "projectedReturn": "...%",
          "expectedCorpus": "...",
          "monthlyInvestment": "...",
          "riskScore": "...",
          "diversificationScore": "...",
          "portfolio": [
            {{ "name": "...", "percent": ... }},
            ...
          ],
          "tips": ["...", "..."]
        }}
        """

        # 🔁 Call LLM with the dynamic prompt
        result = call_llm_for_plan(user_prompt)

        # 🧹 Fallback sanitization
        if "portfolio" not in result or not isinstance(result["portfolio"], list):
            result["portfolio"] = []

        required_fields = [
            "summary", "projectedReturn", "expectedCorpus",
            "monthlyInvestment", "riskScore", "diversificationScore"
        ]

        for field in required_fields:
            result.setdefault(field, "N/A")

        result.setdefault("tips", [])

        return result


    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
