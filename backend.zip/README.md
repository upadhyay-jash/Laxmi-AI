# 💰 Finance RAG Chatbot Backend

Welcome to the **Finance RAG (Retrieval-Augmented Generation) Chatbot Backend!** 🚀

This project uses LangChain, Pinecone, and Hugging Face embeddings to build a chatbot capable of answering finance-related questions by retrieving relevant knowledge and generating accurate, context-rich answers.

---

## 💡 Features

* 🔎 Semantic search on finance documents using Pinecone.
* 🤖 High-quality embeddings with Hugging Face models.
* ⚡ Clean, minimal, and production-ready vector store code.
* 💬 Modular design ready for frontend integration.

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────┐
│      User Query Input       │
└─────────────┬───────────────┘
              │
              ▼
┌─────────────────────────────┐
│    Query Embedding (HF)     │ ← Embed the user question
└─────────────┬───────────────┘
              │
              ▼
┌─────────────────────────────┐
│    Pinecone Vector Store    │ ← Search most similar docs
└─────────────┬───────────────┘
              │
              ▼
┌─────────────────────────────┐
│  Retrieved Relevant Docs    │ ← Top K finance-related docs
└─────────────┬───────────────┘
              │
              ▼
┌─────────────────────────────┐
│  LLM or Chatbot Generator   │ ← Generate final answer
└─────────────┬───────────────┘
              │
              ▼
┌─────────────────────────────┐
│         User Reply          │ ← Show summarized response
└─────────────────────────────┘
```

---

## 💠 Pinecone Vector Store Flow

```
               ┌──────────────────────┐
               │   Text Documents     │ ← Finance knowledge docs
               └─────────┬────────────┘
                         │
                         ▼
        ┌─────────────────────────────────┐
        │   Hugging Face Embeddings       │ ← Converts to vector (dim 768)
        └─────────┬───────────────────────┘
                  │
                  ▼
          ┌────────────────────┐
          │ Pinecone Index     │ ← Store + search vectors
          └─────────┬──────────┘
                    │
         ┌──────────▼──────────┐
         │ Upsert & Similarity │ ← Upsert new vectors, search top-K
         │ Search Operations   │
         └──────────┬──────────┘
                    │
        ┌───────────▼────────────┐
        │ Retrieved Top Documents│
        └───────────┬────────────┘
                    │
        ┌───────────▼────────────┐
        │  Display to User / LLM │ ← Answer generation
        └────────────────────────┘
```

---

## 🛠️ Refactoring Summary

### Before

* Over 100 lines of code in `pinecone_ops.py`.
* Redundant index creation, manual Pinecone API calls, duplicate logic.
* Hard to maintain and debug.

### After

* Clean 23-line file using `langchain_pinecone.PineconeVectorStore`.
* Automatic index checks and streamlined upsert/query logic.
* Reusable embedding and vector store functions.

---

## 📄 Explanation of Key Files

### `pinecone_ops.py`

Handles:

✅ Initializing Pinecone client and index.
✅ Embedding texts using Hugging Face models.
✅ Upserting documents.
✅ Querying top-K relevant results.

### `test_pinecone.py`

Handles:

✅ Preparing example finance documents.
✅ Upserting these docs into Pinecone.
✅ Querying with sample user questions.
✅ Printing retrieved contents clearly.

---

## 💬 How to Explain to Others

> "We embed finance documents into dense vectors using Hugging Face. We store these vectors in Pinecone. When a user asks a question, we embed that question and retrieve the most similar finance docs using Pinecone similarity search. Finally, we generate an LLM-based response using these top docs as context."

---

## 📈 Benefits

* ✅ Simple, clean, and extensible.
* ✅ Clear separation of concerns.
* ✅ Faster vector search using Pinecone.
* ✅ High-quality semantic retrieval.

---

## 🖼️ Diagrams & Visuals

* ✅ Architecture overview diagram.
* ✅ Pinecone flow diagram.
* ✅ (Optional) Call graph diagram — request if needed!

---

## 🚀 Next Steps

* Add full LLM integration to generate final answers.
* Add metadata support (author, date, etc.).
* Integrate with frontend chatbot UI.
* Add chunking for long documents.

---

## ❤️ Contributing

Have suggestions or questions? Feel free to ask or fork this repo and create a pull request!

---

## ⭐️ Let's Build!

Ready to make finance knowledge accessible and conversational. 💬💸

---

**Made with 💙 by Jash**
