export default function getExplanation(formData, projectedReturn, riskScore, diversificationScore, monthlyEMI) {
  const {
    age,
    income,
    expenses,
    goals,
    riskTolerance,
    investmentHorizon
  } = formData;

  const netSavings = income - expenses;
  const yearlyInvestment = monthlyEMI * 12;
  const surplusStatus = netSavings >= monthlyEMI
    ? `You have sufficient monthly surplus (₹${netSavings}) to invest ₹${monthlyEMI}/month.`
    : `Your expenses exceed your EMI capability. Consider reducing your EMI or increasing income.`

  return `
🧑‍💼 Based on your profile:
- Age: ${age}
- Income: ₹${income}
- Expenses: ₹${expenses}
- Risk Tolerance: ${riskTolerance}
- Investment Horizon: ${investmentHorizon} years
- Goals: ${goals}

💡 Investment Strategy:
- Monthly EMI considered: ₹${monthlyEMI}
- Annual Investment: ₹${yearlyInvestment}
- Projected Annual Return: ${projectedReturn}
- Risk Score: ${riskScore}
- Diversification Score: ${diversificationScore}

📊 ${surplusStatus}

This plan aligns your ${investmentHorizon}-year horizon with your ${riskTolerance.toLowerCase()} risk appetite using a diversified asset allocation. It is optimized to balance risk and return while staying consistent with your financial goals.

🧠 You can adjust your EMI or explore more advanced options by chatting with the AI advisor below!
`;
}
