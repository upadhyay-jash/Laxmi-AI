export const generatePlan = async (userId, formData) => {
  const apiUrl = "http://localhost:8000/generate-plan";

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData), // No need to wrap in { user_id }
    });

    if (!response.ok) {
      throw new Error(`FastAPI returned status ${response.status}`);
    }

    const data = await response.json();

    return {
      summary: data.summary,
      projectedReturn: data.projectedReturn,
      expectedCorpus: data.expectedCorpus,
      monthlyInvestment: data.monthlyInvestment,
      riskScore: data.riskScore,
      diversificationScore: data.diversificationScore,
      portfolio: data.portfolio || [],
      tips: data.tips || [],
    };
  } catch (error) {
    console.error("❌ Error generating plan:", error);

    return {
      summary: "⚠️ Unable to generate financial plan right now. Please try again later.",
      projectedReturn: "N/A",
      expectedCorpus: "N/A",
      monthlyInvestment: "N/A",
      riskScore: "N/A",
      diversificationScore: "N/A",
      portfolio: [],
      tips: [],
      error: true,
    };
  }
};
